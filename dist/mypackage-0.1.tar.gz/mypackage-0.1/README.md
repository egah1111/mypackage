# mypackage
This library was created as an example of how to publish your own Python package

# How to install
Go to https://github.com/<egah1111>/<mypackage>